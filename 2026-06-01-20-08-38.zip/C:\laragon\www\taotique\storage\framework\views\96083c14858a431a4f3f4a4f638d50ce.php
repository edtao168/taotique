
<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($journal): ?>
    <?php
        $s = $journal->status;
        $statusLabel = match($s) {
            'draft' => '草稿', 'posted' => '已過帳',
            'cancelled' => '已作廢', 'closed' => '已結案',
            default => $s,
        };
        $statusClass = match($s) {
            'draft' => 'badge-ghost', 'posted' => 'badge-success',
            'cancelled' => 'badge-error', 'closed' => 'badge-info',
            default => 'badge-ghost',
        };
    ?>
    
    <div class="space-y-4">
        <div class="flex items-center gap-2">
            <?php if (isset($component)) { $__componentOriginal4f015fb6508e425790bdb8f79792e6ed = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4f015fb6508e425790bdb8f79792e6ed = $attributes; } ?>
<?php $component = Mary\View\Components\Badge::resolve(['value' => $statusLabel] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Mary\View\Components\Badge::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => ''.e($statusClass).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4f015fb6508e425790bdb8f79792e6ed)): ?>
<?php $attributes = $__attributesOriginal4f015fb6508e425790bdb8f79792e6ed; ?>
<?php unset($__attributesOriginal4f015fb6508e425790bdb8f79792e6ed); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4f015fb6508e425790bdb8f79792e6ed)): ?>
<?php $component = $__componentOriginal4f015fb6508e425790bdb8f79792e6ed; ?>
<?php unset($__componentOriginal4f015fb6508e425790bdb8f79792e6ed); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal4f015fb6508e425790bdb8f79792e6ed = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4f015fb6508e425790bdb8f79792e6ed = $attributes; } ?>
<?php $component = Mary\View\Components\Badge::resolve(['value' => $journal->source_type_label ?? '手動分錄'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Mary\View\Components\Badge::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'badge-outline']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4f015fb6508e425790bdb8f79792e6ed)): ?>
<?php $attributes = $__attributesOriginal4f015fb6508e425790bdb8f79792e6ed; ?>
<?php unset($__attributesOriginal4f015fb6508e425790bdb8f79792e6ed); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4f015fb6508e425790bdb8f79792e6ed)): ?>
<?php $component = $__componentOriginal4f015fb6508e425790bdb8f79792e6ed; ?>
<?php unset($__componentOriginal4f015fb6508e425790bdb8f79792e6ed); ?>
<?php endif; ?>
        </div>

        <div class="bg-base-200 p-4 rounded-lg space-y-2 text-sm">
            <div class="flex justify-between">
                <span class="text-gray-500">傳票編號</span>
                <span class="font-mono font-bold">#<?php echo e($journal->id); ?></span>
            </div>
            <div class="flex justify-between">
                <span class="text-gray-500">交易日</span>
                <span class="font-mono"><?php echo e($journal->entry_date->format('Y-m-d')); ?></span>
            </div>			
            <div class="font-medium">
				<span class="text-gray-500">🏪 分店</span>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($journal->shop): ?>
                    <?php echo e($journal->shop->name ?? $journal->shop->shop_name ?? '未設定'); ?>

                    <span class="text-xs text-gray-400">(ID: <?php echo e($journal->shop_id); ?>)</span>
                <?php else: ?>
                    <span class="text-gray-400">未關聯分店</span>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
            <div class="flex justify-between">
                <span class="text-gray-500">幣別 / 匯率</span>
                <span class="font-mono"><?php echo e($journal->currency); ?> @ <?php echo e($journal->exchange_rate); ?></span>
            </div>
        </div>

        <div class="p-4 border border-base-300 rounded-lg">
            <div class="text-xs text-gray-500 mb-1">摘要</div>
            <div class="font-bold"><?php echo e($journal->description); ?></div>
        </div>

        
        <div class="border border-base-300 rounded-lg overflow-hidden">
            <table class="table table-sm w-full">
                <thead>
                    <tr class="text-xs text-gray-500">
                        <th>科目</th>
                        <th class="text-right">借方</th>
                        <th class="text-right">貸方</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $journal->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="text-sm">
                                <span class="font-mono text-xs bg-base-300 px-1 rounded"><?php echo e($item->account->code); ?></span>
                                <?php echo e($item->account->name); ?>

                            </td>
                            <td class="text-right font-mono <?php echo e(bccomp($item->debit, '0', 4) > 0 ? 'text-success font-bold' : 'text-gray-300'); ?>">
                                <?php echo e(bccomp($item->debit, '0', 4) > 0 ? number_format($item->debit, 2) : '-'); ?>

                            </td>
                            <td class="text-right font-mono <?php echo e(bccomp($item->credit, '0', 4) > 0 ? 'text-error font-bold' : 'text-gray-300'); ?>">
                                <?php echo e(bccomp($item->credit, '0', 4) > 0 ? number_format($item->credit, 2) : '-'); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?><?php /**PATH C:\laragon\www\taotique\resources\views/livewire/accountings/includes/_journal-detail.blade.php ENDPATH**/ ?>