{{-- resources/views/livewire/sales/create.blade.php --}}
<div x-data="{ 
        atBottom: false,
        checkScroll() {
            let scrollHeight = Math.max(
                document.body.scrollHeight, document.documentElement.scrollHeight,
                document.body.offsetHeight, document.documentElement.offsetHeight,
                document.body.clientHeight, document.documentElement.clientHeight
            );
            this.atBottom = (window.innerHeight + window.scrollY) >= (scrollHeight - 150);
        }
     }" 
     x-init="checkScroll()"
     @scroll.window.debounce.50ms="checkScroll()">
	 
    <x-header separator progress-indicator>
		@if($errors->any())
			<div class="alert alert-error mb-4 shadow-lg">
				<x-icon name="o-exclamation-triangle" class="w-6 h-6" />
				<div>
					<h3 class="font-bold">請修正以下錯誤：</h3>
					<ul class="list-disc list-inside text-sm mt-1">
						@foreach($errors->all() as $error)
							<li>{{ $error }}</li>
						@endforeach
					</ul>
				</div>
			</div>
		@endif
		<x-slot:title>
			<div class="flex items-center gap-4">
				<div class="p-3 bg-primary/10 rounded-2xl text-primary">
					<x-icon name="o-chart-bar" class="w-8 h-8" />
				</div>
				<div>
					<h1 class="text-2xl font-bold tracking-tight text-base-content">
						{{ $isEdit ? '修改銷售單' : '新增銷售單' }}
					</h1>
					<div class="flex items-center gap-2 mt-1">
						<span class="badge badge-outline badge-sm font-mono opacity-70">{{ $isEdit ? $sale->invoice_number : $invoice_number }}</span>
						<span class="badge badge-ghost badge-sm uppercase tracking-tighter">Inventory Outbound</span>
					</div>
				</div>
			</div>
		</x-slot:title>
		<x-slot:actions>
			<x-button label="返回列表" icon="o-arrow-left" link="/sales" class="btn-ghost" />
			<x-button label="確認過帳" icon="o-check" class="btn-primary shadow-md hover:shadow-lg transition-all px-8" wire:click="save" spinner />
		</x-slot:actions>
	</x-header>

    <div class="grid grid-cols-1 lg:grid-cols-12 gap-6 pb-24">
        <div class="lg:col-span-8 space-y-6">
			{{-- 1. 單據資訊 --}}
            <x-card title="單據資訊" shadow class="border-t-4 border-primary">
				<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
					<x-choices 
						label="客戶" 
						wire:model="form.customer_id" 
						:options="$customers" 
						single 
						icon="o-users" 
					/>

					<x-datetime 
						label="成交時間" 
						wire:model.live="form.sold_at" 
						icon="o-clock" 
						type="datetime-local"
					/>
					
					@php
						$isAuto = (bool) App\Models\Setting::get('so_auto_stock_out', true);
					@endphp
					
					<div class="p-3 bg-base-200/50 rounded-lg border border-dashed border-base-300 flex items-center gap-3">
						<x-icon :name="$isAuto ? 'o-check-circle' : 'o-pause-circle'" 
								:class="$isAuto ? 'text-success' : 'text-warning'" />
						<div class="text-xs">
							<span class="font-bold">目前庫存處理模式：</span>
							{{ $isAuto ? '過帳即扣庫存' : '過帳僅存檔待後續進行出庫' }}
						</div>
					</div>
				
					<x-choices 
						label="分店" 
						wire:model="form.shop_id" 
						:options="$shops"
						single 
						icon="o-building-storefront"
					/>

					<x-choices 
						label="銷售通路" 
						wire:model="form.channel_id"
						:options="$channels"
						single
						icon="o-globe-alt"
					/>
					
					<x-select 
						label="付款方式" 
						wire:model.live="form.payment_method" 
						:options="config('business.payment_methods')" 
						icon="o-banknotes" 
					/>

					<x-select 
						label="業務歸屬倉庫" 
						wire:model="form.warehouse_id" 
						:options="$warehouses" 
						placeholder="請選擇倉庫"  
						icon="o-home-modern" 
					/>
				</div>
				<div class="mt-4">
					<x-textarea 
						label="備註" 
						wire:model.live="form.remark" 
						rows="2"
					/>
				</div>
            </x-card>

			{{-- 2. 商品明細 --}}		
			<x-card shadow separator class="mb-4 lg:mb-0 border-t-4 border-primary">
				<x-slot:title>
					<div class="flex justify-between items-center w-full">
						<span class="font-bold text-xl text-base-content">銷售明細</span>
						<div class="flex items-center gap-2">
							<span class="text-xs opacity-50 hidden sm:inline">連續掃描模式</span>
							<x-scanner.button mode="continuous" class="btn-xs btn-outline flex flex-row items-center gap-1" />
						</div>
					</div>
				</x-slot:title>

				{{-- PC 端標頭 --}}
				<div class="hidden lg:grid grid-cols-12 gap-4 mb-2 px-4 text-sm font-bold opacity-60">
					<div class="col-span-5">商品 (搜尋或掃描)</div>
					<div class="col-span-2">發貨倉庫</div>
					<div class="col-span-2 text-right">單價</div>					
					<div class="col-span-1 text-right">數量</div>
					<div class="col-span-2 text-right text-primary">小計</div>
				</div>

				<div class="space-y-3">
					@forelse($items as $index => $item)
                        <div wire:key="sale-row-block-{{ $index }}-{{ $item['product_id'] ?? 'new' }}">
						    <x-sale-row :$index :$item :$warehouses :$productOptions mode="pc" />
						    <x-sale-row :$index :$item :$warehouses :$productOptions mode="mobile" />
                        </div>
					@empty        
						<div class="p-12 text-center bg-base-200/20 rounded-b-lg border-dashed border-2">
							<x-icon name="o-shopping-cart" class="w-12 h-12 mx-auto opacity-20" />
							<p class="mt-2 opacity-50 italic text-sm">尚未加入任何銷售商品，請開始掃描或搜尋</p>
						</div>
					@endforelse
				</div>

				<x-slot:actions>
					<x-button label="手動新增一行商品" icon="o-plus-circle" class="btn-ghost btn-sm w-full border-dashed border-2 hover:border-primary hover:text-primary" wire:click="addRow" />
				</x-slot:actions>
			</x-card>
		</div>

        {{-- 3. 結算區塊 --}}
        <div class="lg:col-span-4 space-y-6">
            <x-card title="結算" shadow class="bg-base-100 border-t-4 border-primary">
                <div class="space-y-4">
                    <div class="flex justify-between items-center p-2 bg-base-200/50 rounded-lg">
                        <span class="font-bold opacity-70">小計</span>
                        <span class="font-mono text-right">NT$ {{ number_format((float) ($form['subtotal'] ?? 0), 2) }}</span>
                    </div>
					<div class="flex justify-between items-center p-3 bg-amber-50 dark:bg-amber-900/20 rounded-lg border border-amber-200 dark:border-amber-800">
						<div class="flex items-center gap-2">
							<x-icon name="o-tag" class="w-5 h-5 text-amber-600" />
							<span class="font-bold text-amber-700 dark:text-amber-400">賣家折扣</span>
							<span class="text-[10px] text-amber-500">(從收入扣除)</span>
						</div>
						<div class="flex items-center gap-2">
							<span class="text-amber-600 font-bold">-</span>
							<x-input 
								wire:model.blur="form.seller_discount"
								class="input-sm text-right font-mono bg-white w-32"

								inputmode="decimal"
								step="1"
								min="0"
							/>
							<span class="text-amber-600">元</span>
						</div>
					</div>
					<div class="grid grid-cols-2 gap-4 text-xs">
						{{-- 左側：買家區塊 --}}
						<div class="space-y-3">
							<div class="badge badge-info badge-outline font-bold px-4 py-3">買家</div>
							
							@foreach(collect(config('business.fee_types'))->where('target', 'customer') as $field => $config)
								<x-input 
									wire:model.blur="form.{{ $field }}"
									label="{{ $config['name'] }}" 
									prefix="{{ $config['operator'] === 'add' ? '+' : '-' }}"
									icon="{{ $config['icon'] ?? '' }}"
									class="input-sm text-right font-mono {{ $config['operator'] === 'sub' ? 'text-error' : '' }}"
									inputmode="decimal"
									step="0.01"
								/>
							@endforeach

							<div class="pt-2 border-t border-dashed">
								<div class="text-[10px] opacity-50">買家實付</div>
								<div class="text-lg font-bold text-blue-600 font-mono">
									NT$ {{ number_format((float) ($form['customer_total'] ?? 0), 2) }}
								</div>
							</div>
						</div>

						{{-- 右側：賣家區塊 --}}
						<div class="space-y-3">
							<div class="badge badge-success badge-outline font-bold px-4 py-3">賣家</div>
							
							@foreach(collect(config('business.fee_types'))->where('target', 'seller') as $field => $config)
								<x-input 
									wire:model.blur="form.{{ $field }}" 
									label="{{ $config['name'] }}" 
									prefix="{{ $config['operator'] === 'add' ? '+' : '-' }}"
									icon="{{ $config['icon'] ?? '' }}"
									class="input-sm text-right font-mono {{ $config['operator'] === 'sub' ? 'text-warning' : '' }}"
									inputmode="decimal"
									step="0.01"
								/>
							@endforeach
						</div>
					</div>

                    <div class="divider my-0"></div>

                    <div class="p-4 bg-emerald-50 dark:bg-emerald-900/20 rounded-xl border border-emerald-100">
                        <div class="text-[15px] text-emerald-600 font-bold tracking-widest uppercase mb-1">最終訂單進帳</div>
                        <div class="text-4xl font-black text-emerald-600 font-mono">
                            NT$ {{ number_format((float) ($form['final_net_amount'] ?? 0), 2) }}
                        </div>
                    </div>

                    <x-button label="確認收銀 / 過帳" icon="o-check" class="btn-primary w-full btn-lg" wire:click="save" spinner />
                </div>
            </x-card>
        </div>
    </div>

	<div x-show="!atBottom" 
		 x-transition:enter="transition ease-out duration-300"
		 x-transition:enter-start="opacity-0 transform translate-y-4"
		 x-transition:leave="transition ease-in duration-300"
		 x-transition:leave-end="opacity-0 transform translate-y-4"		 
		 class="flex fixed bottom-20 right-4 lg:bottom-6 lg:right-6 z-50 pointer-events-none">
		
		<div class="flex flex-col items-center">
			<span class="text-[10px] lg:text-xs font-bold text-orange-600 bg-orange-50 px-2 py-1 rounded-full shadow-sm mb-1">
				下滑查看
			</span>
			<div class="bg-orange-500 text-white p-2 lg:p-3 rounded-full shadow-lg animate-bounce">
				<x-icon name="o-chevron-down" class="w-4 h-4 lg:w-6 lg:h-6" />
			</div>
		</div>
	</div>

    <x-scanner.modal />
    <x-scanner.scripts />
</div>